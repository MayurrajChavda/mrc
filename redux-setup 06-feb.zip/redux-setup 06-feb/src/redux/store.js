import { createStore } from "@reduxjs/toolkit";
import root from "./reducer";

const store = createStore(root);

export default store;