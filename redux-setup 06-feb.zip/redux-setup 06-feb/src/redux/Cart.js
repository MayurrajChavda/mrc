import React from 'react'
import { useSelector } from 'react-redux'


function Cart() {

  const state = useSelector(state=>state);
  console.log("cart",state.CartAction);
  return (
    <>
        <div style={{height:'300px',border:'1px solid black'}}>
          <div className='ms-5'>
            <h1>Cart page</h1>
            {
              state.CartAction.length>0?
              state.CartAction.map(function(value,index){
                  return(
                    <div key={index}>
                      <h4>{value.title}</h4>
                      <button>Delete</button>
                    </div>
                  )
              }):"Cart is empty"
            }
            </div>
        </div>   
    </>
  )
}

export default Cart