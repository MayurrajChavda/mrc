import { combineReducers } from "@reduxjs/toolkit"

const CartAction = (state=[],action) => {  

    console.log(action);
    if(action.type=="add"){
        return [...state,action.data];
    }
    else if(action.type=="remove"){
        return [...state,action.data];
    }

    return state;
}


const root = combineReducers({CartAction});

export default root;