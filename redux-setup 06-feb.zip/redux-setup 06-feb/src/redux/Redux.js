import React from 'react'
import Cart from './Cart'
import product from './product'
import { useDispatch } from 'react-redux'


function Redux() {
    const dispatch = useDispatch();

    const addToCart = (data) => {
        dispatch({data:data,type:"add"});
    }


  return (
    <>
        <div style={{height:'300px',border:'1px solid black'}}>
            <div className='ms-5'>
            <h1>Main Home page</h1>
                {
                    product.map(function(value,index){
                        return(
                            <div key={index}>
                                <h4>{value.title}</h4>
                                <button onClick={()=>{addToCart(value)}}>Add</button>
                            </div>
                        )
                    })
                }
            </div>
        </div>   
        <Cart/>
    </>
  )
}

export default Redux