import { BrowserRouter,Routes,Route } from 'react-router-dom'
import React from 'react'
import Home from '../pages/Home'
import Profile from '../pages/Profile'
import Testing from './Testing'
import Redux from '../redux/Redux'

function MyRouter() {
  return (
    <BrowserRouter>
      <Routes>
      <Route path='/' element={<Home/>}/>
      <Route path='/profile' element={<Profile/>}/>
      <Route path='/testing' element={<Testing/>}/>
      <Route path='/redux' element={<Redux/>}/>
      </Routes>
    </BrowserRouter>
  )
}

export default MyRouter