import React from 'react'
import { 
  createUserWithEmailAndPassword , 
  onAuthStateChanged, 
  signInWithEmailAndPassword,
  signOut
} from "firebase/auth";

import { auth } from '../myFirebase/firebase';

function Testing() {
  let email = "abc@gmail.com";
  let pass = "123456";

  const createUser = () => {
    createUserWithEmailAndPassword(auth,email,pass)
    .then((s)=>{console.log(s)})
    .catch((e)=>{console.log(e.message)});
  }

  const loginUser = () => {
    signInWithEmailAndPassword(auth,email,pass)
    .then((s)=>{console.log(s)})
    .catch((e)=>{console.log(e)});
  }

  const checkUser = () => {
    onAuthStateChanged(auth,function(user){
      console.log(user);
    });
  }

  const signoutUser = () => {
    signOut(auth)
    .then((s)=>{console.log(s)})
    .catch((e)=>{console.log(e)});
  }
  return (
    <div>
      <button onClick={createUser}>SignUp</button>
      <button onClick={loginUser}>SignIn</button>
      <button onClick={checkUser}>Check</button>
      <button onClick={signoutUser}>SignOut</button>
    </div>
  )
}

export default Testing