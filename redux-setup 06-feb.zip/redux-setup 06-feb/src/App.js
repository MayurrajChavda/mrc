import './App.css';
import MyRouter from './components/MyRouter';
import store from './redux/store'
import { Provider } from 'react-redux';
function App() {
  return (
    <Provider store={store}>
      <MyRouter/>
    </Provider>
  );
}

export default App;